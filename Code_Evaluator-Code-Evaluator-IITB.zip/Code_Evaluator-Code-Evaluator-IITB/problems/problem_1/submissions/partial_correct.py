def two_sum(nums: list[int], target: int) -> list[int]:
    seen = {}
    for i, num in enumerate(nums):
        if num < 0:
            continue
        complement = target - num
        if complement in seen:
            return [seen[complement], i]
        seen[num] = i
    return []
